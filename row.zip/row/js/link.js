domReady(() => {
  linkButton()
})

function domReady (callback) {
  if (document.readyState === 'complete') {
    callback()
  } else {
    window.addEventListener('load', callback, false);
  }
}

function linkButton() {
  document.querySelector('.rate').href = `https://chrome.google.com/webstore/detail/${chrome.runtime.id}/reviews`;
  document.querySelector('.facebook').href = `https://www.facebook.com/sharer.php?u=${chrome.runtime.getManifest().homepage_url}`;
  document.querySelector('.pinterest').href = `https://pinterest.com/pin/create/button/?url=${chrome.runtime.getManifest().homepage_url}&desc=${chrome.runtime.getManifest().homepage_url}`;
  document.querySelector('.twitter').href = `https://twitter.com/share?url=${chrome.runtime.getManifest().homepage_url}`;
  document.querySelector('.reddit').href = `https://www.reddit.com/submit?url=${chrome.runtime.getManifest().homepage_url}`;
  document.querySelector('.website').href = `${chrome.runtime.getManifest().homepage_url}`;
}
